python ./tagstore.py --verbose
